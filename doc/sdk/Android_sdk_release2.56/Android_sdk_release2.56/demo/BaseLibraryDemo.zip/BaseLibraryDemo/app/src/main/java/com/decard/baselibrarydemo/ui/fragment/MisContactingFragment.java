package com.decard.baselibrarydemo.ui.fragment;

import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.decard.NDKMethod.BasicOper;
import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.model.DeviceModel;
import com.decard.baselibrarydemo.utils.TypesetRadioGroup;
import com.decard.driver.utils.HexDump;

import java.io.UnsupportedEncodingException;


public class MisContactingFragment extends Fragment implements View.OnClickListener {

    TypesetRadioGroup trgType;


    private String cardType = "C";

    private String result = null;


    private Button mRestorationKey;

    private Button mBtnRestoration;

    private Button mSendBtn;

    private Button mThEelectricit;

    private Button mSelect;

    private TextView mDataShow;

    private TextView mAgainShow;

    private int port;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.fragment_mis_contacting, container, false);

        initview(root);
        return root;
    }
    private void initview(View root) {
        //设置类型
        trgType = root.findViewById(R.id.rg_parent_very);

        //射频复位
        mRestorationKey=root.findViewById(R.id.btn_restoration_key);

        //非接触式CPU卡复位
        mBtnRestoration=root.findViewById(R.id.btn_restoration_refin);

        //非接触式CPU卡指令交互
        mSendBtn=root.findViewById(R.id.btn_send_very);

        //下电
        mThEelectricit=root.findViewById(R.id.The_electricit_very);

        //查询
        mSelect=root.findViewById(R.id.btn_select_very);

        mDataShow=root.findViewById(R.id.btn_data_show);

        mAgainShow=root.findViewById(R.id.btn_restoration_message_);



        mRestorationKey.setOnClickListener(this);

        mBtnRestoration.setOnClickListener(this);

        mSendBtn.setOnClickListener(this);

        mThEelectricit.setOnClickListener(this);

        mSelect.setOnClickListener(this);


        noncontact();

    }
    private void noncontact(){
        trgType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.rb_main_very:
                        cardType = "A";
                        break;
                    case R.id.rb_main_two_very:
                        cardType = "B";
                        break;
                }

                if (cardType == "A") {
                    result = BasicOper.dc_config_card(0x00);
                    String[] resultArr = result.split("\\|", -1);
                    if (resultArr[0].equals("0000")) {
                        Log.d("dc_config_card", "success ");
                    } else {
                        Log.d("dc_config_card", "error code = " + resultArr[0] + " error msg = " + resultArr[1]);
                    }
                } else {
                    result = BasicOper.dc_config_card(0x01);
                    String[] resultArr = result.split("\\|", -1);
                    if (resultArr[0].equals("0000")) {
                        Log.d("dc_config_card", "success ");
                    } else {
                        Log.d("dc_config_card", "error code = " + resultArr[0] + " error msg = " + resultArr[1]);
                    }
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            //射频复位
            case R.id.btn_restoration_key:
                if (cardType=="C"){
                    Toast.makeText(getContext(), "请选择卡类型", Toast.LENGTH_SHORT).show();
                    return;
                }

                String resultRf = BasicOper.dc_reset();
                String[] resultArrRf = resultRf.split("\\|",-1);
                if(resultArrRf[0].equals("0000")) {
                    Log.d("dc_reset","success");
                    Toast.makeText(getActivity(),"射频复位成功",Toast.LENGTH_SHORT).show();
                } else{
                    Log.d("dc_reset","error code = "+resultArrRf[0] +" error msg = "+resultArrRf[1] );
                    Toast.makeText(getActivity(),"射频复位失败:"+resultArrRf[1],Toast.LENGTH_SHORT).show();
                }

                //寻卡请求，防卡冲突
                String result1;
                if (cardType=="A"){
                    result1=BasicOper.dc_card_n_hex(0x01);
                }else {
                    result1=BasicOper.dc_request_b_hex((byte)0x00,(byte) 0x00);
                    Log.d("dc_request_b_hex", result1.split("\\|")[1]);
                    Log.d("dc_attrib", BasicOper.dc_attrib(result1.split("\\|")[1],0x00));
                }
                String[] resultArr1 = result1.split("\\|",-1);
                if(resultArr1[0].equals("0000")){

                    String strInfo = null;
                    strInfo = HexDump.toHexString(resultArr1[1].getBytes());
                    Log.d("dc_card_hex","strInfo = " + strInfo);

                    Log.d("dc_card_hex","success card sn = " + resultArr1[1]);
                }else{
                    Log.d("dc_card_hex","error code = "+resultArr1[0] +" error msg = "+resultArr1[1] );
                }

                break;

            //非接触式CPU卡复位
            case R.id.btn_restoration_refin:
                if (cardType=="C"){
                    Toast.makeText(getContext(), "请选择卡类型", Toast.LENGTH_SHORT).show();
                    return;
                }
                String resultTora;
                if (cardType=="B"){
                    resultTora=BasicOper.dc_card_b_hex();
                }else {
                    resultTora = BasicOper.dc_pro_resetInt_hex();
                }
                String[] resultArr = resultTora.split("\\|",-1);
                if(resultArr[0].equals("0000")){
                    mAgainShow.setText(resultArr[1]);
                    Log.d("dc_pro_resethex","success ATR/ATS = " + resultArr[1]);
                }else{
                    mAgainShow.setText(resultArr[0]);
                    Log.d("dc_pro_resethex","error code = "+resultArr[0] +" error msg = "+resultArr[1] );
                }
                break;

            //非接触式CPU卡指令交互
            case R.id.btn_send_very:
                String resultSen;
                String exist = BasicOper.dc_card_exist();
                String existSplit=exist.split("\\|")[1];
                Log.d("dc_card_exist", "onClick: "+existSplit);
                if (cardType=="B"&&("1008".equals(existSplit)||"5000".equals(existSplit))){
                    resultSen=BasicOper.dc_pro_commandsource_int("0084000008",7);
                }else {
                    resultSen = BasicOper.dc_procommandInt_hex ("0084000008",7);
                }
                String[] resultSenArr = resultSen.split("\\|",-1);
                if(resultSenArr[0].equals("0000")){
                    mDataShow.setText(resultSenArr[1]);
                    Log.d("dc_procommandInt_hex ","success reponse apdu = " + resultSenArr[1]);
                }else{
                    mDataShow.setText(resultSenArr[0]);
                    Log.d("dc_procommandInt_hex ","error code = "+resultSenArr[0] +" error msg = "+resultSenArr[1] );
                }
                break;

            // 终止非接触式CPU卡操作  //下电
            case R.id.The_electricit_very:
                String cpudDown = BasicOper.dc_pro_halt();
                String[] resultDOWN = cpudDown.split("\\|",-1);
                if(resultDOWN[0].equals("0000")){
                    Toast.makeText(getContext(), "下电成功", Toast.LENGTH_SHORT).show();
                    mAgainShow.setText("复位信息");
                    mDataShow.setText("数据显示");
                    Log.d("dc_pro_halt","success");

                }else{
                    Toast.makeText(getContext(), "下电失败", Toast.LENGTH_SHORT).show();
                    Log.d("dc_pro_halt","error code = "+resultDOWN[0] +" error msg = "+resultDOWN[1] );
                }
                break;
            //查询
            case R.id.btn_select_very:
//                String result = BasicOper.dc_card_n_hex(0x01);
//                String result=BasicOper.dc_MulticardStatus();
                String result=BasicOper.dc_card_exist();
                String[] resultSelct = result.split("\\|",-1);
                if(resultSelct[0].equals("0000")){
                    Toast.makeText(getContext(), resultSelct[1], Toast.LENGTH_SHORT).show();
                    Log.d("dc_card_hex","success card sn = " + resultSelct[1]);
                }else{

                    Toast.makeText(getContext(), resultSelct[1], Toast.LENGTH_SHORT).show();
                    Log.d("dc_card_hex","error code = "+resultSelct[1] +" error msg = "+resultSelct[1] ); }
                break;
        }
    }
}
package com.decard.baselibrarydemo;




import androidx.annotation.NonNull;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PersistableBundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;


import com.android.DecardPowerApi;
import com.decard.NDKMethod.BasicOper;


import com.decard.baselibrarydemo.adapter.BluetoothListAdapter;
import com.decard.baselibrarydemo.adapter.CustomSpinnerTAdapter;
import com.decard.baselibrarydemo.model.DeviceModel;

import com.decard.baselibrarydemo.utils.AutoUtils;
import com.decard.baselibrarydemo.utils.BleUtils;
import com.decard.baselibrarydemo.utils.BluetoothUtils;
import com.decard.baselibrarydemo.utils.IoControlUtils;
import com.decard.baselibrarydemo.utils.SPUtils;
import com.decard.baselibrarydemo.utils.SnackbarUtils;
import com.decard.baselibrarydemo.widget.ExtensibleLayout;
import com.decard.baselibrarydemo.widget.WhorlView;
import com.tbruyelle.rxpermissions3.RxPermissions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import io.reactivex.rxjava3.schedulers.Schedulers;


public class MainActivity extends FragmentActivity  implements View.OnClickListener {

    private Context c;

    private String adb="#148FEB";


    private static final String TAG = "MainActivity";

    private RxPermissions rxPermissions;

    private boolean isChange=false;

    private boolean startRead = false;
    //---------------------------------------------------
    private int portSate;
    //链接类型
//    private String deviceType;
    //端口号
//    private String portValue;
    //波特率
//    private int baudRate;

    //链接状态
    private ImageView connectImg;
    private TextView connectState;

    private ExtensibleLayout extensibleLayout;

    private FrameLayout flConnect;
    //usbConn
    private ImageButton usbConn;
    //comConn
    private ImageButton comConn;
    //btConn
    private ImageButton btConn;

    //com端口
    private Spinner spComPath;
    private Spinner spComBaudrate;

    private TextView textConnect;
    private TextView textDisConnect;

    private View comConnectView;

    //蓝牙
    private View bluetoothConnectView;
    private BluetoothUtils mBluetoothUtils;
    private ImageView ivBluetoothConnectState;
    private TextView tvBluetoothConnectState;

    private boolean isSerching;
    private boolean isDialogShowing;
    public static final int REQUEST_OPEN_BT_CODE = 0x01;

    WhorlView wvProgress;
    private BleUtils mBleUtils;

    public ArrayList<BluetoothDevice> deviceList = new ArrayList<>();
    private BluetoothListAdapter bluetoothListAdapter;
    private BluetoothAdapterListener bluetoothAdapterListener;

    private boolean isSupportCom;
    private Map<ImageButton, Boolean> ibSelectMap=new HashMap<>();

    public HashMap<String, BluetoothDevice> deviceMap = new HashMap<>();
    private AlertDialog bluetoothSearchDialog;
    private BluetoothAdapter.LeScanCallback mLeScanCallback;

    private ListView lvDialog;
    private BluetoothDevice selectBluetoothDevice;

    private BluetoothReceiver mBluetoothReceiver;
    private ProgressDialog processDia;

    private SPUtils settingSp;

    private String USB;
    private String BLUETOOTH;
    private String COM = "COM";

    private MainViewModel mainViewModel;

//    private View rootView;
//    private String[] permissionsList=;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setStatusBarColor(this,Color.parseColor(adb));

        rxPermissions = new RxPermissions(this);
        String[] permissionsList;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S){
            permissionsList= new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION};
        }else {
            permissionsList= new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_ADVERTISE,Manifest.permission.BLUETOOTH_CONNECT};

        }
        rxPermissions.request(permissionsList)
                .subscribeOn(Schedulers.io())
                .subscribe(aBoolean -> {
                    if (aBoolean) {
                        startRead = true;
                    } else {
                        runOnUiThread(()->{
                            Toast.makeText(MainActivity.this, "授权失败，功能将无法使用", Toast.LENGTH_SHORT).show();
                        });
                    }
                });

        mainViewModel=new ViewModelProvider(this).get(MainViewModel.class);

        initView();

        ioControl();

        String adb=Build.MODEL;

        Log.d(TAG,"当前设备=================>"+adb);

    }


    private void initView() {
        extensibleLayout=findViewById(R.id.el_port_connect);
        View contentView=extensibleLayout.getContentView();
        View headView=extensibleLayout.getHeaderView();
        connectState=headView.findViewById(R.id.text_title_connect_state);
        connectImg=headView.findViewById(R.id.item_connect_state);

        flConnect=contentView.findViewById(R.id.fl_connect);


        usbConn=contentView.findViewById(R.id.ib_usb_connect);
        comConn=contentView.findViewById(R.id.ib_com_connect);
        textConnect=contentView.findViewById(R.id.text_connect);
        textDisConnect=contentView.findViewById(R.id.text_disconnect);

        btConn=contentView.findViewById(R.id.ib_blutooth_connect);
        wvProgress=findViewById(R.id.wv_progress);
        if (ibSelectMap.size()==0){
            ibSelectMap.put(usbConn, false);
            ibSelectMap.put(comConn, false);
            ibSelectMap.put(btConn, false);
        }

        if (Build.VERSION.SDK_INT>=18){
            mBleUtils = new BleUtils(this);
            mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                    synchronized (deviceMap) {
                        if (deviceMap != null && isSerching) {
                            String bleAddress = device.getAddress();
                            if (deviceMap.containsKey(bleAddress)) {
                                return;
                            }
//                            Log.d("Tag BLE onLeScan", "address:" + bleAddress + "  name:" + device.getName());

                            deviceMap.put(bleAddress, device);
                            mHandler.post(new Runnable() {
                                @Override
                                public void run() {
//                                        bluetoothListAdapter.notifyData(device);
                                    if (!isDialogShowing) {
                                        showDialog();
                                        isDialogShowing = true;
                                    } else {
//                                        mBleUtils.stopLeDevice(mLeScanCallback);
                                        wvProgress.stop();
                                    }
                                    notifyDataChange();
                                }
                            });
                        }
                    }
                }
            };
        }

        usbConn.setOnClickListener(this);
        comConn.setOnClickListener(this);
        btConn.setOnClickListener(this);
        textConnect.setOnClickListener(this);
        textDisConnect.setOnClickListener(this);

        initCom();
        initBt();
        settingSp = new SPUtils(getString(R.string.settingSp));
    }

    //设置状态栏
    public static void setStatusBarColor(Activity activity,int statusColor) {
        Window window = activity.getWindow();
        //取消状态栏透明
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //添加Flag把状态栏设为可绘制模式
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        //设置状态栏颜色
        window.setStatusBarColor(statusColor);
        //设置系统状态栏处于可见状态
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        //让view不根据系统窗口来调整自己的布局
        ViewGroup mContentView = (ViewGroup) window.findViewById(Window.ID_ANDROID_CONTENT);
        View mChildView = mContentView.getChildAt(0);
        if (mChildView != null) {
            ViewCompat.setFitsSystemWindows(mChildView, false);
            ViewCompat.requestApplyInsets(mChildView);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.ib_com_connect:
                mainViewModel.deviceType=COM;
                getAndSetPath_BaudRate();
                showPortConnect(mainViewModel.deviceType);
                break;
            case R.id.ib_usb_connect:
                mainViewModel.deviceType=USB;
                BasicOper.dc_AUSB_ReqPermission(this);
                BasicOper.CreateAndroidContext(this);
                showPortConnect(mainViewModel.deviceType);
                break;
            case R.id.ib_blutooth_connect:
                mainViewModel.deviceType=BLUETOOTH;
                showPortConnect(mainViewModel.deviceType);
                break;
            case R.id.text_connect:
                onConnectPort();
                break;
            case R.id.text_disconnect:
                onDisConnectPort();
                break;
        }

    }

    private void initCom() {
        //判断设备是否支持串口，设置标志位
        String[] portPathExist = BasicOper.dc_getSerialPortPaths();///dev/ttyMT1   new String[]{"/dev/ttyHSL1"};
        String[] portPaths = new String[portPathExist.length + 2];
        if (portPathExist.length != 0) {
            for (int i = 0; i < portPathExist.length; i++) {
                portPaths[i] = portPathExist[i];
            }
        }
        portPaths[portPathExist.length+1]="/dev/ttyUSB0";
        portPaths[portPathExist.length] = "/dev/dc_spi32765.0";
//        String[] portPahts = {"1","2","3"};
        if (portPaths.length == 2) {
            isSupportCom = false;
            return;
        }
//        String[] portPahts = {};
        isSupportCom = true;
        CustomSpinnerTAdapter comPathAdapter = new CustomSpinnerTAdapter(this, portPaths);
        comPathAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        String[] baudrates = getResources().getStringArray(R.array.baudrate);//new String[]{"115200"};
        CustomSpinnerTAdapter comBaudrateAdapter = new CustomSpinnerTAdapter(this, baudrates);
        comBaudrateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        comConnectView = View.inflate(this, R.layout.com_connect, null);
        AutoUtils.auto(comConnectView);
        spComPath = (Spinner) comConnectView.findViewById(R.id.sp_com_path);
        spComBaudrate = (Spinner) comConnectView.findViewById(R.id.sp_com_baudrate);
        spComPath.setAdapter(comPathAdapter);
        spComBaudrate.setAdapter(comBaudrateAdapter);
    }

    private Handler mHandler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            mBleUtils.stopLeDevice(mLeScanCallback);
            wvProgress.stop();
        }
    };


    private void initBt() {
        mBluetoothUtils = new BluetoothUtils();
        bluetoothConnectView = View.inflate(this, R.layout.bluetooth_connect, null);
        AutoUtils.auto(bluetoothConnectView);
        ivBluetoothConnectState = bluetoothConnectView.findViewById(R.id.iv_bluetooth_connect_state);
        tvBluetoothConnectState = bluetoothConnectView.findViewById(R.id.tv_bluetooth_connect_state);
        LinearLayout llBluetoothDetection = bluetoothConnectView.findViewById(R.id.ll_bluetooth_detection);

        bluetoothSearchDialog();
        registerBluetoothReceiver();
        llBluetoothDetection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                bluetoothListAdapter.clear();
                isSerching = true;
                isDialogShowing = false;
                if (mBluetoothUtils.checkBluetooth()) {
                    SnackbarUtils.showShortSnackbar(MainActivity.this, "No Bluetooth module");
                    return;
                }
                if (!mBluetoothUtils.isEnabled()) {
                    requestEnableBluetooth();
                    wvProgress.start();
                }

                if ("BT".equals(BLUETOOTH)) {

                    mBluetoothUtils.scanDevice();
                    wvProgress.start();
                } else if ("BLE".equals(BLUETOOTH)) {
                    if (Build.VERSION.SDK_INT < 18) {
                        Toast.makeText(MainActivity.this, R.string.version_unsupport_ble, Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        if (!mBleUtils.initBLE()) {
                            Toast.makeText(MainActivity.this, R.string.ble_init_error, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        wvProgress.start();
//                        mBleUtils.startDiscovery();
                        mBleUtils.stopLeDevice(mLeScanCallback);
                        mBleUtils.scanLeDevice(mLeScanCallback);
                        mHandler.postDelayed(runnable, 20000);
//                        startScan(10);
                    }
                }
            }
        });
    }

    private void ioControl(){
        if (Build.MODEL.equals(DeviceModel.Z90N.deviceName)){
            DecardPowerApi decardPowerApi=new DecardPowerApi(getBaseContext());
            if (decardPowerApi.getCardReaderState()==0){
                decardPowerApi.setCardReaderState(1);
            }else{
                Toast.makeText(this, "上电成功", Toast.LENGTH_SHORT).show();
            }
        }else if (Build.MODEL.equals(DeviceModel.M200.deviceName)){
            DecardPowerApi decardApi=new DecardPowerApi(getBaseContext());
            if (decardApi.getCardReaderState()==0){
                decardApi.setCardReaderState(1);
            }else{
                Toast.makeText(this, "上电成功", Toast.LENGTH_SHORT).show();
            }
        }else if (Build.MODEL.equals(DeviceModel.P18F.deviceName)){
            DecardPowerApi decardApi=new DecardPowerApi(getBaseContext());
            if (decardApi.getCardReaderState()==0){
                decardApi.setCardReaderState(1);
            }else{
                Toast.makeText(this, "上电成功", Toast.LENGTH_SHORT).show();
            }
        } else if (Build.MODEL.equals(DeviceModel.P10.deviceName)){
            boolean result=IoControlUtils.getInstance().setIoStatus(IoControlUtils.IC_CARDS_PATH, IoControlUtils.IOSTATUS.ENABLE);
            IoControlUtils.getInstance().setIoStatus(IoControlUtils.POGO_A_PORT_PATH, IoControlUtils.IOSTATUS.ENABLE);
            IoControlUtils.getInstance().setIoStatus(IoControlUtils.POGO_B_PORT_PATH, IoControlUtils.IOSTATUS.ENABLE);
            IoControlUtils.getInstance().setIoStatus(IoControlUtils.SMART_READER_PATH, IoControlUtils.IOSTATUS.ENABLE);
            if (result){
                Toast.makeText(this, "读卡器上电成功", Toast.LENGTH_SHORT).show();

            }else{
                Toast.makeText(this, "读卡器上电失败", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getAndSetPath_BaudRate() {
        SharedPreferences deviceInfo =getSharedPreferences("DEVICE_PATH_BAUDRATE", MODE_PRIVATE);
        String path = deviceInfo.getString("device_path", null);
        int baudRateTemp = deviceInfo.getInt("device_baudRate", 0);
        if (path != null && baudRateTemp != 0) {
            Log.d("savePath_BaudRate", "Read Path and BaudRate success!");
            mainViewModel.portValue = path;
            mainViewModel.baudRate = baudRateTemp;
            setSpinnerItemSelectedByValue(spComPath, mainViewModel.portValue);
            setSpinnerItemSelectedByValue(spComBaudrate, mainViewModel.baudRate + "");
        }

    }

    public void savePath_BaudRate(String path, int baud) {
        SharedPreferences deviceInfo =getSharedPreferences("DEVICE_PATH_BAUDRATE", MODE_PRIVATE);
        SharedPreferences.Editor editor = deviceInfo.edit();
        editor.putString("device_path", path);
        editor.putInt("device_baudRate", baud);
        editor.commit();
        Log.d("savePath_BaudRate", "Save Path and BaudRate success!");
    }


    public static void setSpinnerItemSelectedByValue(Spinner spinner, String value) {
        SpinnerAdapter apsAdapter = spinner.getAdapter(); //得到SpinnerAdapter对象
        int k = apsAdapter.getCount();
        for (int i = 0; i < k; i++) {
            if (value.equals(apsAdapter.getItem(i).toString())) {
                spinner.setSelection(i, true);// 默认选中项
                break;
            }
        }
    }


    private void bluetoothSearchDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final View bluetoothSearchView = getLayoutInflater().inflate(R.layout.dialog_bluetooth, null);
        bluetoothSearchDialog = builder.create();
        bluetoothSearchDialog.setView(bluetoothSearchView, 0, 0, 0, 0);
        bluetoothSearchDialog.setCanceledOnTouchOutside(false);

        lvDialog = (ListView) bluetoothSearchView.findViewById(R.id.lv_dialog);
        bluetoothListAdapter = new BluetoothListAdapter(this, null);
        lvDialog.setAdapter(bluetoothListAdapter);
        setBluetoothAdapterListener(bluetoothListAdapter);
        lvDialog.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                isDialogShowing = false;
                if (mBleUtils != null && mLeScanCallback != null) {
                    isSerching = false;
                    mBleUtils.stopLeDevice(mLeScanCallback);
                    wvProgress.stop();
                }
                bluetoothAdapterListener.onSelectItem(position);
                selectBluetoothDevice = bluetoothListAdapter.getSelectBluetoothDevice(position);
                bluetoothSearchDialog.dismiss();
                mBluetoothUtils.stopScanDevice();
                ivBluetoothConnectState.setActivated(true);
                if (selectBluetoothDevice.getName() == null || selectBluetoothDevice.getName().isEmpty()) {
                    tvBluetoothConnectState.setText(selectBluetoothDevice.getAddress());
                } else {
                    tvBluetoothConnectState.setText(selectBluetoothDevice.getName());
                }
            }
        });
    }

    private void registerBluetoothReceiver() {

        unregisterBluetoothReceiver();

        mBluetoothReceiver = new BluetoothReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);//获取扫描结果
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);//开始扫描
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);//结束扫描
        HandlerThread mHandlerThread = new HandlerThread("thread");
        mHandlerThread.start();
        Looper looper = mHandlerThread.getLooper();
        Handler handler = new Handler(looper);
        this.registerReceiver(mBluetoothReceiver, filter, null, handler);
    }

    private void unregisterBluetoothReceiver() {
        try {
            if (mBluetoothReceiver != null) {
                this.unregisterReceiver(mBluetoothReceiver);
            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_BT_CODE) {
            wvProgress.stop();
            if (resultCode == RESULT_OK) {
                SnackbarUtils.showShortSnackbar(this, "Bluetooth has been turned on");
            } else {
                SnackbarUtils.showShortSnackbar(this, "Bluetooth open failed");
            }
        }
    }

    private void requestEnableBluetooth() {
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(intent, REQUEST_OPEN_BT_CODE);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        isChange=true;
        Log.d(TAG, "onSaveInstanceState: +++++++++++++++++++++++++++");
    }

    private void portSelector(ImageButton ib) {
        flConnect.removeAllViews();
        ib.setSelected(true);
        ibSelectMap.put(ib, true);
        for (Map.Entry<ImageButton, Boolean> imageButtonBooleanEntry : ibSelectMap.entrySet()) {
            ImageButton ibSelect = imageButtonBooleanEntry.getKey();
            if (ibSelect != ib) {
                ibSelect.setSelected(false);
                ibSelectMap.put(ibSelect, false);
            }
        }
    }

    private void showPortConnect(String deviceType) {

        if (!extensibleLayout.isShowing()) {
            extensibleLayout.expand();
        }
        if (deviceType.equals(USB)) {
            portSelector(usbConn);
        }
        if (deviceType.equals(COM)) {
            if (isSupportCom) {
                portSelector(comConn);
                flConnect.addView(comConnectView);  //comConnectView = null ?
            } else {
                SnackbarUtils.showShortSnackbar(this, getString(R.string.device_no_support_serial_port));
            }
        }
        if (deviceType.equals(BLUETOOTH)) {
            portSelector(btConn);
            flConnect.addView(bluetoothConnectView);
        }
    }

    public void onConnectPort() {
        Log.d("Tag", "deviceType:" + mainViewModel.deviceType + "   BLUETOOTH:" );
        mainViewModel.portValue = "";
        mainViewModel.baudRate = -1;
        if (mainViewModel.deviceType.equals(USB)) {
            mainViewModel.portValue = "";
            mainViewModel.baudRate = 0;
        }
        if (mainViewModel.deviceType.equals(COM)) {
            if (mainViewModel.portValue != (String) spComPath.getSelectedItem() || mainViewModel.baudRate != Integer.parseInt((String) spComBaudrate.getSelectedItem())) {
                mainViewModel.portValue = (String) spComPath.getSelectedItem();//"/dev/ttyHSL1";
                mainViewModel.baudRate = Integer.parseInt((String) spComBaudrate.getSelectedItem());
                Log.d("ReadWriteUtil", "自己手动选择了串口路径或者波特率！");
            }
        }
        if (mainViewModel.deviceType.equals(BLUETOOTH)) {  //remote version info [88:1b:99:07:67:44]   88:1B:99:07:67:44   type:BT
            if (selectBluetoothDevice != null) {
                mainViewModel.portValue = selectBluetoothDevice.getAddress();
            } else {
                SnackbarUtils.showShortSnackbar(this, getString(R.string.please_search_bt_device));
                return;
            }
            mainViewModel.baudRate = 0;
            showProgress(getString(R.string.connecting_bt_device), false);
        }
        if (mainViewModel.baudRate == -1) {
            SnackbarUtils.showShortSnackbar(this, getString(R.string.choose_connect_type));
        } else {
            new Thread() {
                @Override
                public void run() {
                    portSate = BasicOper.dc_open(mainViewModel.deviceType, MainActivity.this, mainViewModel.portValue, mainViewModel.baudRate);
                    DeviceModel.setPort(portSate);
                    Log.d("dc_open_logan", "portSate:" + portSate);
                    if (portSate >= 0) {
                        BasicOper.dc_beep(5);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                connectState.setText(R.string.string_connect_state);
                                connectImg.setImageDrawable(getResources().getDrawable(R.drawable.connect));
                                if (mainViewModel.portValue != "" && mainViewModel.baudRate != 0 && mainViewModel.baudRate != -1) {          //串口连接成功
                                    savePath_BaudRate(mainViewModel.portValue, mainViewModel.baudRate);                  //保存串口路径和波特率
                                }
                            }
                        });
                    }
                    Log.d("TagT", "portSate:" + portSate);
                    if (processDia != null) {
                        processDia.cancel();
                    }
                    SnackbarUtils.showShortSnackbar(MainActivity.this, portSate >= 0 ? getString(R.string.openSuccessed) : getString(R.string.openFail));
                }
            }.start();
        }
    }

    public void onDisConnectPort() {
        int close_status = BasicOper.dc_exit();
        DeviceModel.setPort(-1);
        portSate = -1;
        mainViewModel.deviceType = "";
        connectState.setText(R.string.device_no_connect);
        connectImg.setImageDrawable(this.getResources().getDrawable(R.drawable.home_ic_no_connect));
        flConnect.removeAllViews();

        for (Map.Entry<ImageButton, Boolean> imageButtonBooleanEntry : ibSelectMap.entrySet()) {
            ImageButton ibSelect = imageButtonBooleanEntry.getKey();
            ibSelect.setSelected(false);
            ibSelectMap.put(ibSelect, false);
        }
        SnackbarUtils.showShortSnackbar(this, close_status >= 0 ? "The port is close successfully" : "Port has closed");
    }


    private void showDialog() {
        if (bluetoothSearchDialog != null && !bluetoothSearchDialog.isShowing()) {
            bluetoothSearchDialog.show();
        }
    }

    private void dismisDialog() {
        if (bluetoothSearchDialog != null && bluetoothSearchDialog.isShowing()) {
            bluetoothSearchDialog.dismiss();
        }
    }

    public void notifyDataChange() {
        if (deviceMap == null || deviceList == null) {
            return;
        }

        Iterator iterator = deviceMap.entrySet().iterator();
        while (iterator.hasNext()) {
            HashMap.Entry entry = (Map.Entry) iterator.next();
            String address = (String) entry.getKey();
            BluetoothDevice device = (BluetoothDevice) entry.getValue();
//            Log.d("Tag", "address:" + address + "  name:" + device.getName());
            if ((address != null) && (device != null)) {
                int k = findBluetoothDevice(address, deviceList);
                if (k < 0)
                    deviceList.add(device);
                else
                    deviceList.set(k, device);
            }
            bluetoothListAdapter.notifyData(device);
        }
    }

    private int findBluetoothDevice(String paramString, ArrayList<BluetoothDevice> paramArrayList) {
        Log.d("Tag", "deviceList.size:" + paramArrayList.size());
        for (int i = 0; i < paramArrayList.size(); i++)
            if (((BluetoothDevice) paramArrayList.get(i)).getAddress().equals(paramString)) {
                return i;
            }
        return -1;
    }

    private class BluetoothReceiver extends BroadcastReceiver {

        private BluetoothDevice bluetoothDevice;

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            switch (action) {
                case BluetoothDevice.ACTION_FOUND:
                    Log.d("Tag", "has found BLE");
                    bluetoothDevice = intent
                            .getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (bluetoothDevice != null && !TextUtils.isEmpty(bluetoothDevice.getName())) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                wvProgress.stop();
                                bluetoothListAdapter.notifyData(bluetoothDevice);
                                showDialog();
                            }
                        });
                    }
                    break;
                case BluetoothAdapter.ACTION_DISCOVERY_STARTED:
                    break;
                case BluetoothAdapter.ACTION_DISCOVERY_FINISHED:
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            wvProgress.stop();
                            dismisDialog();
                            SnackbarUtils.showShortSnackbar(MainActivity.this, "蓝牙扫描结束");
                        }
                    });
                    break;
            }
        }
    }

    public void showProgress(String message, boolean isCancelable) {
        if (processDia == null) {
            processDia = new ProgressDialog(this, R.style.dialog);
            //点击提示框外面是否取消提示框
            processDia.setCanceledOnTouchOutside(false);
            //点击返回键是否取消提示框
            processDia.setCancelable(isCancelable);
            processDia.setIndeterminate(true);
            processDia.setMessage(message);
        }
        processDia.show();
    }

    public interface BluetoothAdapterListener {
        void onSelectItem(int postion);
    }

    protected void setBluetoothAdapterListener(BluetoothAdapterListener bluetoothAdapterListener) {
        this.bluetoothAdapterListener = bluetoothAdapterListener;
    }

    @Override
    protected void onResume() {
        super.onResume();
        USB = settingSp.getString(getString(R.string.usbKey), getString(R.string.androidUsb));
        BLUETOOTH = settingSp.getString(getString(R.string.bluetoothKey), getString(R.string.bluetooth));
        if (btConn.isSelected()) {
            mainViewModel.deviceType = BLUETOOTH;
        }
        if (usbConn.isSelected()) {
            mainViewModel.deviceType = USB;
        }
        if (comConn.isSelected()){
            mainViewModel.deviceType=COM;
        }
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy: ================================");
        super.onDestroy();
        unregisterBluetoothReceiver();
        DeviceModel.setPort(-1);
        BasicOper.dc_exit();
    }

}




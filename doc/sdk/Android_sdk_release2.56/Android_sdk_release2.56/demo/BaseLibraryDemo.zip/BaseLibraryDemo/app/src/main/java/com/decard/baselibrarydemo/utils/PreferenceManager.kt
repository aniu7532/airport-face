package com.decard.baselibrarydemo.utils

import android.content.Context
import android.content.SharedPreferences
import com.decard.baselibrarydemo.App

object PreferenceManager {



    @JvmStatic
    private fun getSharedPreference(): SharedPreferences {
        return App.app.getSharedPreferences("${App.app.packageName}_sp", Context.MODE_PRIVATE)
    }

    @JvmStatic
    fun getString(context: Context, key: String, defValue: String? = null): String? {
        return getSharedPreference().getString(key, defValue)
    }

    @JvmStatic
    fun getInt(context: Context, key: String, defValue: Int = -1): Int {
        return getSharedPreference().getInt(key, defValue)
    }

    @JvmStatic
    fun getLong(context: Context, key: String, defValue: Long = -1): Long {
        return getSharedPreference().getLong(key, defValue)
    }

    @JvmStatic
    fun getBoolean(context: Context, key: String, defValue: Boolean = false): Boolean {
        return getSharedPreference().getBoolean(key, defValue)
    }

    @JvmStatic
    fun getFloat(context: Context, key: String, defValue: Float = -1F): Float {
        return getSharedPreference().getFloat(key, defValue)
    }

    @JvmStatic
    fun setString(context: Context, key: String, value: String) {
        getSharedPreference().edit().putString(key, value).apply()
    }

    @JvmStatic
    fun setInt(context: Context, key: String, value: Int) {
        getSharedPreference().edit().putInt(key, value).apply()
    }

    @JvmStatic
    fun setLong(context: Context, key: String, value: Long) {
        getSharedPreference().edit().putLong(key, value).apply()
    }

    @JvmStatic
    fun setFloat(context: Context, key: String, value: Float) {
        getSharedPreference().edit().putFloat(key, value).apply()
    }

    @JvmStatic
    fun setBoolean(context: Context, key: String, value: Boolean) {
        getSharedPreference().edit().putBoolean(key, value).apply()
    }

    @JvmStatic
    fun setStringSet(context: Context, key: String, value: Set<String>) {
        getSharedPreference().edit().putStringSet(key, value).apply()
    }

    @JvmStatic
    fun getStringSet(context: Context, key: String, value: Set<String>): Set<String>? {
        return getSharedPreference().getStringSet(key, value)
    }

    /**
     * 清除所有数据
     *
     * @param context
     */
    @JvmStatic
    fun clear(context: Context) {
        getSharedPreference().edit().clear().apply()
    }
}
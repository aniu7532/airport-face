package com.decard.baselibrarydemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.utils.AutoUtils;

import java.util.List;


/**
 * Created by Dell on 2017/2/22.
 */

public class PieceDataAdapter extends RecyclerView.Adapter<PieceDataAdapter.ViewHolder> {


    private final LayoutInflater mInflater;
    private List<SectorDataBean> sectorDataBeanList;

    public PieceDataAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
    }

    public void setPieceData(List<SectorDataBean> sectorDataBeanList) {
        this.sectorDataBeanList = sectorDataBeanList;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View rootView = mInflater.inflate(R.layout.item_piece, parent, false);
        ViewHolder viewHolder = new ViewHolder(rootView);
        viewHolder.tvPieceZero = (TextView) rootView.findViewById(R.id.tv_piece_zero);
        viewHolder.tvPieceOne = (TextView) rootView.findViewById(R.id.tv_piece_one);
        viewHolder.tvPieceTwo = (TextView) rootView.findViewById(R.id.tv_piece_two);
        viewHolder.tvPieceThree = (TextView) rootView.findViewById(R.id.tv_piece_three);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (sectorDataBeanList != null) {
           SectorDataBean sectorData = sectorDataBeanList.get(position);
            if (sectorData != null) {
                holder.tvPieceZero.setText(sectorData.pieceZero);
                holder.tvPieceOne.setText(sectorData.pieceOne);
                holder.tvPieceTwo.setText(sectorData.pieceTwo);
                holder.tvPieceThree.setText(sectorData.pieceThree);
            }
        }

    }

    @Override
    public int getItemCount() {
        return sectorDataBeanList == null ? 0 : sectorDataBeanList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ViewHolder(View itemView) {
            super(itemView);
            AutoUtils.auto(itemView);
        }

        TextView tvPieceZero;
        TextView tvPieceOne;
        TextView tvPieceTwo;
        TextView tvPieceThree;

    }


}

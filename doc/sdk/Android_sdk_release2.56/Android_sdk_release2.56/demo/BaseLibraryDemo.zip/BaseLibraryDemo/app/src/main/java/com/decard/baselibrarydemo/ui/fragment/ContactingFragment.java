package com.decard.baselibrarydemo.ui.fragment;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.decard.NDKMethod.BasicOper;
import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.model.DeviceModel;
import com.decard.baselibrarydemo.utils.TypesetRadioGroup;


public class ContactingFragment extends Fragment {

    private TypesetRadioGroup rgParent;



    private int sn = -1;

    private Button mRestoration;

    private TextView mText;

    private Button mInstruct;

    private Button mElectricity;

    private TextView mMsseawge;

    private int port;

    private boolean startRead = false;

    private boolean mFacility = false;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.fragment_contacting, container, false);


        initview(root);

        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private void initview(View root){
        rgParent = (TypesetRadioGroup) root.findViewById(R.id.rg_parent);

        mRestoration=root.findViewById(R.id.btn_restoration_just);

        mText=root.findViewById(R.id.btn_restoration_message);

        mInstruct=root.findViewById(R.id.btn_just_send);

        mElectricity=root.findViewById(R.id.The_electricit);

        mMsseawge=root.findViewById(R.id.btn_data_show_just);

        startRead();



        /*  port = BasicOper.dc_open("COM", null, "/dev/ttyS0", 115200);*/

        /* port=BasicOper.dc_open("COM", null, "/dev/ttyHSL1", 115200);*/






    }
    private void startRead(){
        rgParent.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
               /* RadioButton radioButton = (RadioButton) group.findViewById(checkedId);
                String result = radioButton.getText().toString();*/
                switch (checkedId){
                    case R.id.rb_main_btn1:
                        sn = 0;
                        break;
                    case R.id.rb_main_btn2:
                        sn = 1;
                        break;
                    case R.id.rb_main_btn3:
                        sn = 2;
                        break;
                    case R.id.rb_main_btn4:
                        sn = 3;
                        break;
                    case R.id.rb_main_btn5:
                        sn = 4;
                        break;
                    case R.id.rb_main_btn6:
                        sn = 5;
                        break;
                }



                BasicOper.dc_setcpu(sn);
            }
        });

        //设置接触式CPU卡参数
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result = BasicOper.dc_setcpupara(0,0x00,0x5C);
                String[] resultArr = result.split("\\|",-1);
                if(resultArr[0].equals("0000")){
                    Log.d("dc_setcpupara","接触式CPU卡参数设置成功");
                    startRead=true;
                }else{
                    Log.d("dc_setcpupara","error code = "+resultArr[0] +" error msg = "+resultArr[1] );
                }

                //检测接触式卡是否在位

                String resultReign = BasicOper.dc_card_status();
                String[] resultArrRegin = resultReign.split("\\|",-1);
                if(resultArrRegin[0].equals("0000")){
                    Log.d("dc_card_status","卡片存在");
                    Log.d("dc_card_status", "resultArrRegin: "+resultArrRegin[1]);
                    startRead=false;
                }else{
                    Log.d("dc_card_status","error code = "+resultArrRegin[0] +" error msg = "+resultArrRegin[1] );
                }
            }
        }).start();



        //接触式CPU卡复位
        mRestoration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (sn==-1){
                    Toast.makeText(getContext(), "请选择卡座类型", Toast.LENGTH_SHORT).show();
                    return;
                }
                String result = BasicOper.dc_cpureset_hex();
                String[] resultArr = result.split("\\|",-1);
                if(resultArr[0].equals("0000")){
                    mText.setText(resultArr[1]);
                    Log.d("dc_cpureset_hex","卡片复位成功，ATR/ATS = "+resultArr[1]);
                }else{
                    mText.setText(resultArr[0]);
                    Log.d("dc_cpureset_hex","error code = "+resultArr[0] +" error msg = "+resultArr[1] );
                }
            }
        });



        //接触式CPU卡指令交互
        mInstruct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String result = BasicOper.dc_cpuapduInt_hex("0084000008");
                String[] resultArr = result.split("\\|",-1);
                if(resultArr[0].equals("0000")){
                    mMsseawge.setText(resultArr[1]);
                    Log.d("dc_cpuapduInt_hex","success response = "+resultArr[1]);
                }else{
                    mMsseawge.setText(resultArr[0]+"设备未打开");
                    Log.d("dc_cpuapduInt_hex","error code = "+resultArr[0] +" error msg = "+resultArr[1] );
                }
            }
        });



        //下电
        mElectricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //对当前卡座CPU卡进行下电操作
                String result = BasicOper.dc_cpudown();
                String[] resultArr = result.split("\\|",-1);
                if(resultArr[0].equals("0000")){
                    Log.d("dc_cpudown","success");
                    Toast.makeText(getContext(), "下电成功", Toast.LENGTH_SHORT).show();
                    mText.setText("复位信息");
                    mMsseawge.setText("数据显示");

                }else{
                    Log.d("dc_cpudown","error code = "+resultArr[0] +" error msg = "+resultArr[1] );
                    Toast.makeText(getContext(), "下电失败", Toast.LENGTH_SHORT).show();
                }
            }
        });




    }

}
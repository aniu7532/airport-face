package com.decard.baselibrarydemo.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

/**
 * Created by Dell on 2017/2/15.
 */

public class TypesetRadioGroup extends RadioGroup {


    private OnCheckedChangeListener mOnCheckedChangeListener;

    public TypesetRadioGroup(Context context) {
        super(context);
    }

    public TypesetRadioGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener listener) {
        mOnCheckedChangeListener = listener;
    }

    @Override
    public void addView(final View child, int index, ViewGroup.LayoutParams params) {
        if (child instanceof LinearLayout) {
            int childCount = ((LinearLayout) child).getChildCount();
            for (int i = 0; i < childCount; i++) {
                View view = ((LinearLayout) child).getChildAt(i);
                if (view instanceof LinearLayout) {
                    int childCount2 = ((LinearLayout) view).getChildCount();
                    for (int n = 0; n < childCount2; n++) {
                        View view2 = ((LinearLayout) view).getChildAt(n);
                        if (view2 instanceof RadioButton) {
                            setCheckedChange(view2);
                        }
                    }
                } else if (view instanceof RadioButton) {
                    setCheckedChange(view);
                }
            }
        } else if (child instanceof RadioButton) {
            setCheckedChange(child);
        }

        super.addView(child, index, params);
    }


    private void  setCheckedChange(View view) {
        final RadioButton button = (RadioButton) view;
        button.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    button.setChecked(true);
                    checkRadioButton(button);
                    if (mOnCheckedChangeListener != null) {
                        mOnCheckedChangeListener.onCheckedChanged(TypesetRadioGroup.this, button.getId());
                    }
                }
                return true;
            }
        });
    }

    private void checkRadioButton(RadioButton radioButton) {
        View child;
        int radioCount = getChildCount();
        for (int i = 0; i < radioCount; i++) {
            child = getChildAt(i);
            if (child instanceof RadioButton) {
                if (child == radioButton) {
                    // do nothing
                } else {
                    ((RadioButton) child).setChecked(false);
                }
            } else if (child instanceof LinearLayout) {
                int childCount = ((LinearLayout) child).getChildCount();
                for (int j = 0; j < childCount; j++) {
                    View view = ((LinearLayout) child).getChildAt(j);
                    if (view instanceof LinearLayout) {
                        int childCount2 = ((LinearLayout) view).getChildCount();
                        for (int n = 0; n < childCount2; n++) {
                            View view2 = ((LinearLayout) view).getChildAt(n);
                            if (view2 instanceof RadioButton) {
                                final RadioButton button = (RadioButton) view2;
                                if (button == radioButton) {
                                    // do nothing
                                } else {
                                    button.setChecked(false);
                                }
                            }
                        }
                    } else if (view instanceof RadioButton) {
                        final RadioButton button = (RadioButton) view;
                        if (button == radioButton) {
                            // do nothing
                        } else {
                            button.setChecked(false);
                        }
                    }

                }
            }
        }
    }


}

package com.decard.baselibrarydemo.adapter;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.utils.AutoUtils;


/**
 * Created by Dell on 2017/2/20.
 */

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.ViewHolder> {



    private final LayoutInflater mInflater;
    private final Context context;
    private String[] sectorsNum;
    private int currentPostion;
    private OnGalleryListener onGalleryListener;

    public GalleryAdapter(Context context, String[] sectorsNum) {
        mInflater = LayoutInflater.from(context);
        this.context = context;
        this.sectorsNum = sectorsNum;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View rootView = mInflater.inflate(R.layout.gallery_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(rootView);
        viewHolder.tvSectors = (TextView) rootView.findViewById(R.id.tv_sectors);
        viewHolder.llSectorsSelect = (LinearLayout) rootView.findViewById(R.id.ll_sectors_select);
        return viewHolder;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.tvSectors.setText(sectorsNum[position]);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPostion = position;
                if (onGalleryListener != null) {
                    onGalleryListener.itemClick(v,currentPostion);
                }
                notifyDataSetChanged();
            }
        });
        if (currentPostion == position) {
            holder.llSectorsSelect.setBackground(context.getResources().getDrawable(R.drawable.sectors_shape));
            holder.tvSectors.setTextColor(context.getResources().getColor(R.color.colorWhite));
        } else {
            holder.llSectorsSelect.setBackground(null);
            holder.tvSectors.setTextColor(context.getResources().getColor(R.color.colorBlack));
        }
    }

    @Override
    public int getItemCount() {
        return sectorsNum.length;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ViewHolder(View itemView) {
            super(itemView);
            AutoUtils.auto(itemView);
        }

        LinearLayout llSectorsSelect;
        TextView tvSectors;
    }

    public interface OnGalleryListener{
        void itemClick(View view, int postion);
    }
    public void setOnGalleryListener(OnGalleryListener onGalleryListener) {
        this.onGalleryListener = onGalleryListener;
    }

    public void setSelectItem(int currentPostion) {
        this.currentPostion = currentPostion;
        notifyDataSetChanged();
    }
}

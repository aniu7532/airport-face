package com.decard.baselibrarydemo.model;

public enum DeviceModel {

    P18F("P18F"),
    F11("f11_x1"),
    Z90N("Z90N"),
    P18Q("p18q_dual"),
    M200("M200-Q3"),
    P10("P10"),
    F10("f10_x1");


    public final String deviceName;
    private static int globalPort = -1;
//    private static int sociaPort=-1;

    DeviceModel(String deviceName) {
        this.deviceName = deviceName;
    }

//    public static void setSoport(int Soport){
//        sociaPort = Soport;
//    }
//    public static int getSoport(){
//        return sociaPort;
//    }





    public static void setPort(int port){
        globalPort = port;
    }

    public static int getPort(){
        return globalPort;
    }
}

package com.decard.baselibrarydemo.adapter;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;


import com.decard.baselibrarydemo.MainActivity;
import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.ui.fragment.HomeFragment;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Dell on 2017/2/6.
 */

public class BluetoothListAdapter extends BaseAdapter implements MainActivity.BluetoothAdapterListener {


    private List<BluetoothDevice> bluetoothDeviceList;
    private final LayoutInflater mInflater;
    private int selectPostion;
    private Set<BluetoothDevice> bluetoothDeviceSet;

    public BluetoothListAdapter(Context context, List<BluetoothDevice> bluetoothDeviceList) {
        this.bluetoothDeviceList = bluetoothDeviceList;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return bluetoothDeviceList == null ? 0 : bluetoothDeviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate(R.layout.item_dialog_bluetooth, parent, false);
            viewHolder.rbBluetoothRadio = (RadioButton) convertView.findViewById(R.id.rb_bluetooth_radio);
            viewHolder.tvBluetoothName = (TextView) convertView.findViewById(R.id.tv_bluetooth_name);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        BluetoothDevice bluetoothDevice = bluetoothDeviceList.get(position);
        String address = bluetoothDevice.getAddress();
        String name = bluetoothDevice.getName();
        if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(address)) {
            viewHolder.tvBluetoothName.setText(name);
        }else if (!TextUtils.isEmpty(address)){
            viewHolder.tvBluetoothName.setText(address);
        }
        if (selectPostion == position) {
            viewHolder.rbBluetoothRadio.setChecked(true);
        } else {
            viewHolder.rbBluetoothRadio.setChecked(false);
        }

        return convertView;
    }

    public void clear() {
        if (bluetoothDeviceList != null && bluetoothDeviceSet != null) {
            bluetoothDeviceList.clear();
            bluetoothDeviceSet.clear();
            bluetoothDeviceList = null;
            bluetoothDeviceSet = null;
        }
        notifyDataSetChanged();
    }

    private class ViewHolder {
        RadioButton rbBluetoothRadio;
        TextView tvBluetoothName;
    }


    public void notifyData(BluetoothDevice bluetoothDevice) {
        if (bluetoothDeviceList == null && bluetoothDeviceSet == null) {
            bluetoothDeviceSet = new LinkedHashSet<>();
            bluetoothDeviceList = new ArrayList<>();
        }
        if (bluetoothDeviceSet.contains(bluetoothDevice)) {

            return;

        }
        bluetoothDeviceSet.add(bluetoothDevice);
        bluetoothDeviceList.clear();
        bluetoothDeviceList.addAll(bluetoothDeviceSet);
        notifyDataSetChanged();
    }

    @Override
    public void onSelectItem(int postion) {
        this.selectPostion = postion;
        notifyDataSetChanged();
    }

    public BluetoothDevice getSelectBluetoothDevice(int postion) {
        return bluetoothDeviceList.get(postion);
    }


}

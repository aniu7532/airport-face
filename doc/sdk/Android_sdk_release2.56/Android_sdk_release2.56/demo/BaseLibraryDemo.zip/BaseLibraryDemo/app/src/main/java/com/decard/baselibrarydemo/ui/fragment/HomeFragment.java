package com.decard.baselibrarydemo.ui.fragment;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.model.DeviceModel;
import com.decard.baselibrarydemo.ui.CpuActivity;
import com.decard.baselibrarydemo.utils.SnackbarUtils;


public class HomeFragment extends Fragment {


    private static final String TAG = "HomeFragment";

    private TextView mIdCard;


    private TextView mScan;

    private TextView mCpuCard;

    private TextView mM1Id;

    private TextView mFingerprin;

    View.OnClickListener clickListener  =new View.OnClickListener(){
        @Override
        public void onClick(View view) {

            switch (view.getId()){
                case R.id.btn_id_card:
                    if (DeviceModel.getPort()<0){
                        SnackbarUtils.showShortSnackbar(getActivity(),"请先打开端口");
                    }else {
                        Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_idCardFragment);
                    }
                    break;
                case R.id.btn_qr_code:
                    if (Build.MODEL.equals(DeviceModel.P10.deviceName)){
                        Toast.makeText(getContext(), "暂不支持P10设备，请联系支持", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (DeviceModel.getPort()<0){
                        SnackbarUtils.showShortSnackbar(getActivity(),"请先打开端口");
                    }else {
                        Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_scanCodeFragment);
                    }
                    break;
                case R.id.btn_cpu_card:
                    if (DeviceModel.getPort()<0){
                        SnackbarUtils.showShortSnackbar(getActivity(),"请先打开端口");
                    }else {
                        Intent intent = new Intent(getActivity(), CpuActivity.class);
                        startActivity(intent);
                    }
                    break;

                case R.id.btn_m1_card:
                    if (DeviceModel.getPort()<0){
                        SnackbarUtils.showShortSnackbar(getActivity(),"请先打  开端口");
                    }else {
                        Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_m1CardFragment);
                    }
                    break;
                case R.id.btn_fingerprint:
//                    if (DeviceModel.getPort()<0){
//                        SnackbarUtils.showShortSnackbar(getActivity(),"请先打开端口");
//                    }else {
//                        Navigation.findNavController(view).navigate(R.id.action_homeFragment_to_fingerprintFragment);
//                    }
                    break;
            }
        }
    };





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView=inflater.inflate(R.layout.fragment_home, container, false);
//        initData(rootView);
        LinearLayout naLayout=getActivity().findViewById(R.id.na_layout);
        naLayout.setVisibility(View.VISIBLE);
        initview(rootView);
        return rootView;
    }

    private void initview(View root){
        mIdCard=root.findViewById(R.id.btn_id_card);
//        mSocial=root.findViewById(R.id.btn_social_card);
        mScan=root.findViewById(R.id.btn_qr_code);
        mCpuCard=root.findViewById(R.id.btn_cpu_card);
        mM1Id=root.findViewById(R.id.btn_m1_card);
        mFingerprin=root.findViewById(R.id.btn_fingerprint);

        String adb=Build.MODEL;
        Log.d(TAG,"设备名称"+adb);

        mFingerprin.setVisibility(root.INVISIBLE);
//        if (Build.MODEL.equals(DeviceModel.Z90N.deviceName)){
//            mFingerprin.setVisibility(root.INVISIBLE);
//        }else if (Build.MODEL.equals(DeviceModel.P18F.deviceName)){
//            mFingerprin.setVisibility(root.INVISIBLE);
//        }else if(Build.MODEL.equals(DeviceModel.P18Q.deviceName)){
//            mFingerprin.setVisibility(root.INVISIBLE);
//        }else if (Build.MODEL.equals(DeviceModel.F11.deviceName)){
//            mFingerprin.setVisibility(root.INVISIBLE);
//        }



        mIdCard.setOnClickListener(clickListener);
//        mSocial.setOnClickListener(clickListener);
        mScan.setOnClickListener(clickListener);
        mCpuCard.setOnClickListener(clickListener);
        mM1Id.setOnClickListener(clickListener);
        mFingerprin.setOnClickListener(clickListener);


    }

}
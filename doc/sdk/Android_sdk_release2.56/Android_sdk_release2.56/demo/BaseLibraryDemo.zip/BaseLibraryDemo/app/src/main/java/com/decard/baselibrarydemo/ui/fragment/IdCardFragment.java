package com.decard.baselibrarydemo.ui.fragment;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.decard.NDKMethod.BasicOper;

import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.model.DeviceModel;
import com.decard.entitys.IDCard;

import java.io.UnsupportedEncodingException;

public class IdCardFragment extends Fragment {
    private static final String TAG = "ShowIdCardFragment";

    private String mName;

    private String mSex;

    private String mNation;

    private String mBirth;

    private String mAddress;

    private String mNumber;

    private LottieAnimationView mLottieIdcard;

    private boolean startRead = false;

    private String mSigFor;

    private String mValidTime;


    private ImageView mReturn;

    private int port;

    boolean bCardPowerOn = false;

    private Bundle mBundle;

    private Handler mHandler;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_first_id_card, container, false);
        initview(root);
        LinearLayout naLayout=getActivity().findViewById(R.id.na_layout);
        naLayout.setVisibility(View.GONE);
        return root;
    }

    private void initview(View root) {


        mLottieIdcard = root.findViewById(R.id.lottie_fingerprint_id_card);

        mReturn = root.findViewById(R.id.btn_return_key_id_card);

        //寻找图片
        mLottieIdcard.setImageAssetsFolder("ldcard/");
        //播放
        mLottieIdcard.playAnimation();


        mHandler = new Handler() {
            @Override
            public void handleMessage(@NonNull Message msg) {
                if (msg.what == 10) {
                    start(root);
                }
            }
        };
        mReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startRead = false;
                Navigation.findNavController(view).popBackStack();
            }
        });


        startRead = true;
        startRead(root);

    }

    private void startRead(View root) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                while (startRead) {
                    try {
                        //身份证
                        long start=System.currentTimeMillis();
                        IDCard idCard = BasicOper.dc_SamAReadCardInfo(1);
                        Log.e(TAG, "dc_SamAReadCardInfo: "+ (System.currentTimeMillis()-start));
                        if (idCard != null) {
                            mName = idCard.getName().replace(" ","");
                            mSex = idCard.getSex();
                            Log.d(TAG, "run:"+mName+mSex);
                            mNation = idCard.getNation();
                            mBirth = idCard.getBirthday();
                            mAddress = idCard.getAddress();
                            mNumber = idCard.getId();
                            mSigFor = idCard.getOffice();
                            mValidTime = idCard.getStartTime()+"-"+idCard.getEndTime();
                            byte[] adb = idCard.getPhotoData();
                            try {
                                Log.e(TAG, "idCard.getPhotoData():"+new String(adb,"UTF8").trim());
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
//                            Log.d(TAG, "run: "+idCard.getPhotoDataHexStr());
//                            Log.d(TAG, "run: "+new String(idCard.getPhotoData()));
//                            Log.d(TAG, "run: "+ idCard.getPhotoData());
//                            Log.d(TAG,"88888888888888"+adb);

                            mBundle = new Bundle();
                            mBundle.putString("name", mName);
                            mBundle.putString("sex", mSex);
                            mBundle.putString("nation", mNation);
                            mBundle.putString("birth", mBirth);
                            mBundle.putString("address", mAddress);
                            mBundle.putString("number", mNumber);
                            mBundle.putString("sigFor", mSigFor);
                            mBundle.putString("validTime", mValidTime);
                            mBundle.putByteArray("phone", adb);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(adb, 0, adb.length);

                            mHandler.sendEmptyMessageDelayed(10,0);
                          /*  getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                     Navigation.findNavController(root).navigate(R.id.action_idCardFragment_to_showIdCardFragment2,mBundle);
                                    startRead = false;
                                }
                            });
*/

                        } else {
                            Log.d(TAG, "idCardFragment: 读取失败");
                        }
                     /*    IDCard idCard = BasicOper.dc_get_i_d_raw_info();*/

                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }


            }
        }).start();

    }

    private void start(View root){
        Navigation.findNavController(root).navigate(R.id.action_idCardFragment_to_showIdCardFragment2,mBundle);
       /* mHandler.removeCallbacksAndMessages(null);*/
        startRead = false;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        startRead = false;
        if (mHandler!=null)mHandler.removeCallbacksAndMessages(null);
    }


}

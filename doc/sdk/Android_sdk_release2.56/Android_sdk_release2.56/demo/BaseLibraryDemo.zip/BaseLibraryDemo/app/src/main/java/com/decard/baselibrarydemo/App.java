package com.decard.baselibrarydemo;


import android.app.Application;

import com.decard.baselibrarydemo.utils.Utils;

public class App extends Application {

    public static App app;

    public Object object = new Object();

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        Utils.init(getApplicationContext());
//        CrashReport.initCrashReport(getApplicationContext(), "d6cf707f40", true);
//        LogConfiguration config = new LogConfiguration.Builder()
//                .logLevel(BuildConfig.DEBUG ? LogLevel.ALL             // 指定日志级别，低于该级别的日志将不会被打印，默认为 LogLevel.ALL
//                        : LogLevel.NONE)
//                .tag("BaseLibrary")                                           // 指定 TAG，默认为 "X-LOG"
//                .t()                                                   // 允许打印线程信息，默认禁止
//                .st(2)                                                 // 允许打印深度为2的调用栈信息，默认禁止
//                .b()                                                   // 允许打印日志边框，默认禁止
//                .build();
//        Printer androidPrinter = new AndroidPrinter();
//        Printer filePrinter = new FilePrinter// 打印日志到文件的打印器
//                .Builder("/sdcard/BaseLibraryLog/")
//                .fileNameGenerator(new DateFileNameGenerator())// 指定保存日志文件的路径
//                .build();
//        XLog.init(config,filePrinter,androidPrinter);

    }

    public static App getInstance(){
        return app;
    }
}

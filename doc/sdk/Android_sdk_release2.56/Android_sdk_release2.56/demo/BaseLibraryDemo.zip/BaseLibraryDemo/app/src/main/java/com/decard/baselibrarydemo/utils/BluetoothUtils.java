package com.decard.baselibrarydemo.utils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;

public class BluetoothUtils {

    BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    BluetoothManager mBluetoothManager;

    public boolean checkBluetooth() {
        return (mBluetoothAdapter == null);
    }


    /**
     * bluetooth on or off
     */
    public boolean isEnabled() {
        return mBluetoothAdapter.isEnabled();
    }


    /**
     * start scan bluetooth device
     */
    public boolean scanDevice() {
        if (mBluetoothAdapter.isDiscovering()) {
            mBluetoothAdapter.cancelDiscovery();
        }
//		mBluetoothManager.getAdapter().getBluetoothLeScanner().
        return mBluetoothAdapter.startDiscovery();
    }

    /**
     * stop scan bluetooth device
     */
    public boolean stopScanDevice() {
        if (mBluetoothAdapter.isDiscovering()) {
            return mBluetoothAdapter.cancelDiscovery();
        }
        return false;
    }


    public BluetoothAdapter getAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        return mBluetoothAdapter;
    }
}

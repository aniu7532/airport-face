package com.decard.baselibrarydemo.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.decard.baselibrarydemo.MainActivity;
import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.ui.fragment.ContactingFragment;
import com.decard.baselibrarydemo.ui.fragment.MisContactingFragment;

public class CpuActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG ="CpuActivity" ;

    private TextView mContactCpu;

    private TextView mNoContactCpu;

    private ContactingFragment f1;

    private MisContactingFragment f2;

    private String adb="#148FEB";

    private ImageView mReturn;

    private String mBackColro="#F4F9FC";

    private String mReturnColor="#ffffff";

    private String mTextClor="#148FEB";

    private String mTextReturnCilor="#1F1F1F";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cpu);
        initview();

//        WindowManager.LayoutParams params = getWindow().getAttributes();
//
//        params.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE;
//
//        getWindow().setAttributes(params);
//        MainActivity.setStatusBarColor(this, Color.parseColor(adb));
    }
    private void initview(){
        mContactCpu=findViewById(R.id.text_btn);
        mNoContactCpu=findViewById(R.id.text_btn_two);
        mReturn=findViewById(R.id.btn_return_key_cpu);
        mContactCpu.setOnClickListener(this);
        mNoContactCpu.setOnClickListener(this);

        mReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if(f1 == null){
            f1 = new ContactingFragment();

            transaction.add(R.id.frament_container_home ,f1);
            transaction.commit();
        }else{
            if (f2!=null){
                transaction.hide(f2);
                transaction.show(f1);
                transaction.commit();
            }



        }
        //隐藏所有fragment
        //显示需要显示的fragment
    }

    private void nocontactless(){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if(f2 == null){
            f2 = new MisContactingFragment();
            transaction.hide(f1);
            transaction.add(R.id.frament_container_home ,f2);
            transaction.commit();
        }else{
            transaction.hide(f1);
            transaction.show(f2);
            transaction.commit();
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.text_btn:
                initview();
               /* */
               /* int i = Integer.valueOf(mBackColro).intValue();*/
                //颜色切换
                mContactCpu.setBackgroundColor(Color.parseColor(mBackColro));
                mNoContactCpu.setBackgroundColor(Color.parseColor(mReturnColor));
                mContactCpu.setTextColor(Color.parseColor(mTextClor));
                mNoContactCpu.setTextColor(Color.parseColor(mTextReturnCilor));
                Log.d(TAG, "text_btn: ");
                break;

            case R.id.text_btn_two:
                nocontactless();
                //颜色切换
                mNoContactCpu.setBackgroundColor(Color.parseColor(mBackColro));
                mContactCpu.setBackgroundColor(Color.parseColor(mReturnColor));
                mNoContactCpu.setTextColor(Color.parseColor(mTextClor));
                mContactCpu.setTextColor(Color.parseColor(mTextReturnCilor));
//                mContactCpu.setBackgroundColor(Color.parseColor(mBackColro));
                Log.d(TAG, "text_btn_two: ");
                break;
    }
}
}
package com.decard.baselibrarydemo.ui.fragment;

import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.SystemClock;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import com.cunoraz.gifview.library.GifView;
import com.decard.NDKMethod.BasicOper;
import com.decard.baselibrarydemo.model.DeviceModel;
import com.decard.baselibrarydemo.utils.IoControlUtils;
import com.decard.baselibrarydemo.R;
import com.decard.driver.utils.HexDump;

import java.io.UnsupportedEncodingException;


public class ScanCodeFragment extends Fragment {

    private static final String TAG = "ScanCodeFragment";


    private TextView mResuit;


    private boolean startRead = false;

    private boolean startReadCard = false;

    private  String scan_2D_info;

    private ImageView mReturn;

    private GifView gifView;

    private LottieAnimationView mLottieAnimationView;

    private boolean result;

    private int port;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.fragment_scan_code, container, false);
        LinearLayout naLayout=getActivity().findViewById(R.id.na_layout);
        naLayout.setVisibility(View.GONE);


        gifView= (GifView) root.findViewById(R.id.lottie_fingerprint_im);
        //设置图片源
        gifView.setGifResource(R.drawable.qrc);//本地图片


        mReturn=root.findViewById(R.id.btn_return_key_scan);
        mReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).popBackStack();
                startRead=false;
                startReadCard=false;
            }
        });
            //读卡器
            cardinitview(root);


        return root;
    }


    //读卡器扫  码
    private void cardinitview(View root){
        mResuit=root.findViewById(R.id.btn_scan_code);
            startReadCard = true;
            startReadCard();
    }

    private void startReadCard() {
        //开启二维码扫描
        String start_scan_2D = BasicOper.dc_Scan2DBarcodeStart(0x00);
        Log.d(TAG, "run:二维码"+start_scan_2D);
        if (start_scan_2D.split("\\|")[0].equals("0000")) {
            new Thread(new Runnable() {
                @Override
                public void run() {

                    while (startReadCard){
                        try {
                            scan_2D_info = BasicOper.dc_Scan2DBarcodeGetData();
                            //获取二维码扫描结果
                            Log.d(TAG, "BasicOper.dc_Scan2DBarcodeGetData：" + scan_2D_info);
                            if (scan_2D_info.split("\\|")[0].equals("0000")) {
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        String data= null;
                                        try {
                                            data = new String(HexDump.hexStringToByteArray(scan_2D_info.split("\\|")[1]),"Gbk").trim();
                                            Log.d(TAG, "111111111: "+data);
                                            mResuit.append("\n"+"\n"+data+"\n");
                                        } catch (UnsupportedEncodingException e) {
                                            e.printStackTrace();
                                        }

                                       /* mResuit.setText(scan_2D_info+"/n");*/
                                    }
                                });
                            }
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        startRead = false;
        startReadCard = false;

    }


}
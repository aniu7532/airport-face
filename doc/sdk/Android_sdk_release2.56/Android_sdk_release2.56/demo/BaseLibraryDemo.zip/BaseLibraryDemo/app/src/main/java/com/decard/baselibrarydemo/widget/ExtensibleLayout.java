package com.decard.baselibrarydemo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.decard.baselibrarydemo.R;


/**
 * Created by Dell on 2017/2/5.
 */

public class ExtensibleLayout extends RelativeLayout {

    private FrameLayout headerLayout;
    private FrameLayout contentLayout;
    private View headerView;
    private View contentView;
    private Context context;

    public ExtensibleLayout(Context context) {
        super(context);
    }

    public ExtensibleLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context,attrs);
    }



    public ExtensibleLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context,attrs);
    }

    public View getHeaderView(){
        return headerView;
    }

    public View getContentView(){
        return contentView;
    }


    public boolean isShowing() {
        return contentLayout.getVisibility() == VISIBLE;
    }

    public void close() {
        Animation closeAnim = AnimationUtils.loadAnimation(context, R.anim.extensible_hide);
        closeAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                contentLayout.setVisibility(GONE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        contentLayout.startAnimation(closeAnim);
    }

    public void expand() {
        contentLayout.setVisibility(VISIBLE);
        Animation expandAnim = AnimationUtils.loadAnimation(context, R.anim.extebsible_show);
        contentLayout.startAnimation(expandAnim);
    }


    private void init(Context context, AttributeSet attrs) {
        this.context = context;
        View rootView = View.inflate(context, R.layout.extebsible_layout, this);
        headerLayout = (FrameLayout) rootView.findViewById(R.id.extebsible_headerlayout);
        contentLayout = (FrameLayout) rootView.findViewById(R.id.extebsible_contentlayout);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ExtensibleLayout);
        int headerId = a.getResourceId(R.styleable.ExtensibleLayout_headerlayout, -1);
        final int contentId = a.getResourceId(R.styleable.ExtensibleLayout_contentlayout, -1);

        if (headerId == -1 || contentId == -1) {
            throw new IllegalArgumentException("HeaderLayout and ContentLayout cannot be null");
        }

        if (isInEditMode()) {
            return;
        }

        headerView = View.inflate(context, headerId, headerLayout);
        contentView = View.inflate(context, contentId, contentLayout);
        contentLayout.setVisibility(GONE);
        headerLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                show();
            }
        });

        a.recycle();

    }

    private void show() {
        if (contentLayout.getVisibility() == VISIBLE) {
            close();
        }else {
            expand();
        }
    }

}

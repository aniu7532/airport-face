//package com.decard.baselibrarydemo.ui.fragment;
//
//import android.graphics.Bitmap;
//import android.graphics.BitmapFactory;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.Looper;
//import android.os.Message;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.navigation.Navigation;
//
//import com.airbnb.lottie.LottieAnimationView;
//import com.decard.baselibrarydemo.App;
//import com.decard.baselibrarydemo.R;
//import com.decard.baselibrarydemo.utils.IoControlUtils;
//
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//
//
//
//
//public class FingerprintFragment extends Fragment {
//
//    private FingerprintScanner mScanner;
//
//    private int mLfdLevel = FingerprintScanner.LFD_LEVEL_OFF;
//
//    private static final String TAG = "ScanCodeFragment";
//
//    private static final String FP_DB_PATH = "/sdcard/fp.db";
//
//    private ImageView mResult;
//
//    private ImageView mReturn;
//
//    private ImageView mFingerprint;
//
//    private LottieAnimationView mLottieAnimationView;
//
//    private boolean gainUsb = false;
//
//    private FingerprintImage fi = null;
//
//    private boolean startReadSuit = false;
//    private final ExecutorService executorService = Executors.newCachedThreadPool();
//
//    private Handler mHandler = new Handler(Looper.getMainLooper()) {
//        @Override
//        public void handleMessage(@NonNull Message msg) {
//            super.handleMessage(msg);
//            Log.e(TAG, "handleMessage: ============>"+msg.what);
//            if (!executorService.isShutdown()){
//                if (msg.what == 10) {
//                    executorService.execute(()-> statOpen());
//                }
//            }
//        }
//    };
//
//
//
//
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        View root=inflater.inflate(R.layout.fragment_fingerprint, container, false);
//        if (getActivity()!=null) {
//            LinearLayout naLayout=getActivity().findViewById(R.id.na_layout);
//            naLayout.setVisibility(View.GONE);
//        }
//        mLottieAnimationView=root.findViewById(R.id.lottie_fingerprint_im);
//        mLottieAnimationView.setImageAssetsFolder("lp/");
//        mLottieAnimationView.playAnimation();
//
//        mReturn=root.findViewById(R.id.btn_return_key_fagment);
//
//        mResult=root.findViewById(R.id.btn_fragment);
//
//        mReturn.setOnClickListener(view -> {
//            Navigation.findNavController(view).popBackStack();
//            if (mScanner!=null)mScanner.close();
//            mHandler.removeCallbacksAndMessages(null);
//            executorService.shutdown();
//        });
//        //LoadingDialog 加载
////        LoadingDialog();
//
////        Toast.makeText(getContext(), "状态"+result, Toast.LENGTH_SHORT).show();
//        //USB下电操作
//
//
//
//
//        executorService.execute(()->{
//            try {
//                Thread.sleep(50);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            //关闭usb连接
//            int adb= IoControlUtils.getInstance().getIoStatus(IoControlUtils.USB_PATH);
//            if (adb==1){
//                boolean result= IoControlUtils.getInstance().setIoStatus(IoControlUtils.USB_PATH, IoControlUtils.IOSTATUS.DISABLE);
//                try {
//                    Thread.sleep(3000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//            //上电
//            boolean res= IoControlUtils.getInstance().setIoStatus(IoControlUtils.ARATEK_FP_PATH, IoControlUtils.IOSTATUS.ENABLE);
//            if (!res){
//                try {
//                    Thread.sleep(3000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                Log.d(TAG,"指纹仪上电成功");
//            }else{
//                Log.d(TAG,"指纹仪上电失败");
//            }
//            initviwe(root);
//        });
//        // 可更新UI或做其他事情
//        // 注意这里还在当前线程，没有开启新的线程
//        //指纹模块上电
//
//
//
//
//
//        return root;
//    }
//
//
//    private void initviwe(View root) {
//
//        mScanner = new FingerprintScanner(App.app);
//        if (getActivity()!=null)
//        getActivity().runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                startRead();
//            }
//        });
//
//
//    }
//
//    private void startRead(){
//        int error;
//        if ((error = mScanner.open()) != FingerprintScanner.RESULT_OK) {
//            Log.d(TAG,"打开失败");
//        }else{
//            mScanner.setLfdLevel(mLfdLevel);
//        }
//        Log.d(TAG, "mScanner.open()===="+error);
//        if ((error = Bione.initialize(getContext(), FP_DB_PATH)) != Bione.RESULT_OK) {
//            Log.d(TAG,"失败"+error);
//        }else{
//            Toast.makeText(getContext(), "算法初始化成功"+error, Toast.LENGTH_SHORT).show();
//            Log.d(TAG,"成功"+error);
//            startReadSuit=true;
//
//
//            mHandler.sendEmptyMessageDelayed(10,3000);
//     /*       mHandler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//
//                }
//            }, 10,);*/
//        }
//
//
//
//
//    }
//
//    private void statOpen(){
//        Log.e(TAG, "statOpen: executorService.isShutdown=="+executorService.isShutdown());
//        if (!executorService.isShutdown()){
//            Result res;
//            long startTime, captureTime = -1, extractTime = -1, generalizeTime = -1, verifyTime = -1;
//            int capRetry = 0;
//            int prepare = mScanner.prepare();
//            Log.d(TAG, "statOpen: (Scanner.prepare())："+prepare);
//            while (true){
//                startTime = System.currentTimeMillis();
//                res = mScanner.capture();
//                Log.d(TAG, "statOpen(mScanner.capture): "+res);
//                captureTime = System.currentTimeMillis() - startTime;
//                fi = (FingerprintImage) res.data;
////            int quality;
////            if (fi != null) {
////                quality = Bione.getFingerprintQuality(fi);
////                Log.i(TAG, "Fingerprint image quality is " + quality);
////                if (quality < 50 && capRetry < 3 ) {
////                    capRetry++;
////                    continue;
////                }
////            }
//                if (res.error != FingerprintScanner.NO_FINGER) {
//                    break;
//                }
//            }
//            mScanner.finish();
//            Log.e(TAG, "statOpen: res.err==="+res.error+",res.data==="+res.data );
//            if (res.error != FingerprintScanner.RESULT_OK) {
//                if (getActivity()!=null)
//                getActivity().runOnUiThread(()->{
//                    Toast.makeText(App.app, "采集指纹图像失败", Toast.LENGTH_SHORT).show();
//
//                });
//
//            }else{
//                byte[] asdb= fi.convert2Bmp();
//                Bitmap bitmap;
//                if (fi!=null&&asdb!=null){
//                    bitmap= BitmapFactory.decodeByteArray(asdb,0,asdb.length);
//                    if (getActivity()!=null)
//                    getActivity().runOnUiThread(()->{
//                        mResult.setImageBitmap(bitmap);
//                    });
//
//                }else{
//                    if (getActivity()!=null)
//                    getActivity().runOnUiThread(()->{
//                        Toast.makeText(App.app, "获取指纹图像失败", Toast.LENGTH_SHORT).show();
//                    });
//                }
//            }
//            Log.e(TAG, "sendEmptyMessageDelayed: ");
//
//            mHandler.sendEmptyMessageDelayed(10,1500);
//        }
//    }
//
//  /*  private void LoadingDialog(){
//        LoadingDialogUilis.Builder builder=new LoadingDialogUilis.Builder(getContext())
//                .setMessage("设备打开中...请稍等")
//                .setCancelable(false);
//        final LoadingDialogUilis dialog=builder.create();
//        dialog.show();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                dialog.dismiss();
//            }
//        },3000);
//    }*/
//
///*    private void  LoadingDialogStart(){
//        LoadingDialogUilis.Builder builder=new LoadingDialogUilis.Builder(getContext())
//                .setMessage("请按压指纹")
//                .setCancelable(false);
//        final LoadingDialogUilis dialog=builder.create();
//        dialog.show();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                dialog.dismiss();
//            }
//        },5000);
//    }*/
//  /*  private Handler handler=new Handler(){
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//        }
//    };*/
//
//
//    @Override
//    public void onDestroyView() {
//        if (mScanner!=null)mScanner.close();
//        mHandler.removeCallbacksAndMessages(null);
//        executorService.shutdown();
//        super.onDestroyView();
//        Log.e(TAG, "onDestroyView: ");
//    }
//
//}
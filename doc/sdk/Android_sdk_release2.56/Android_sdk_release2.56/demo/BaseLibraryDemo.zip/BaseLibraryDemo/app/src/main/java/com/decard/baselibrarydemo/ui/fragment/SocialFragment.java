//package com.decard.baselibrarydemo.ui.fragment;
//
//import android.os.Bundle;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.navigation.Navigation;
//
//import android.os.Handler;
//import android.os.Message;
//import android.util.Log;
//import android.view.KeyEvent;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.airbnb.lottie.LottieAnimationView;
//import com.decard.NDKMethod.BasicOper;
//import com.decard.NDKMethod.SSCardDriver;
//import com.decard.baselibrarydemo.R;
//import com.decard.baselibrarydemo.model.DeviceModel;
//
//import java.io.UnsupportedEncodingException;
//
//
//public class SocialFragment extends Fragment {
//
//    private static final String TAG = "SocialFragment";
//
//    private boolean mStartRead = false;
//
//
//    private Button mButton;
//
//    private String mName;
//
//    private String mCode;
//
//    private TextView mSex;
//
//    private String mBonth;
//
//    private String mNum;
//
//    private   String infoCard;
//
//    private ImageView mReturn;
//
//    private int port;
//
//    private LottieAnimationView mLottieSocal;
//
//    private long cardBas;
//
//    private Handler mHandler;
//
//    private Bundle mBundle;
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        View root= inflater.inflate(R.layout.fragment_social, container, false);
//        /* LoadingDialogStart();*/
//        initview(root);
//        return root;
//    }
//    private void initview(View root){
//        mLottieSocal=root.findViewById(R.id.lottie_fingerprint_id_card);
//
//        mReturn=root.findViewById(R.id.btn_return_key_social);
//
//
//        //寻找图片
//        mLottieSocal.setImageAssetsFolder("social/");
//        //播放
//        mLottieSocal.playAnimation();
//
//        mHandler=new Handler(){
//            @Override
//            public void handleMessage(@NonNull Message msg) {
//                if (msg.what == 10) {
//                    start(root);
//                }
//
//                if (msg.what==20){
//                    if (getContext()!=null){
//                        Toast.makeText(getContext(), "读取失败", Toast.LENGTH_SHORT).show();
//                    }
//
//                }
//            }
//        };
//
//        mReturn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                mStartRead = false;
//
//                Navigation.findNavController(view).popBackStack();
//
//
//            }
//        });
//
//  /*      root.setFocusableInTouchMode(true);
//        root.requestFocus();
//        root.setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//                if(keyCode == KeyEvent.KEYCODE_BACK){
//
//                    return !mRead;
//                }
//
//                return false;
//            }
//        });*/
//
//
//
//        if(DeviceModel.getSoport()==0){
//            Log.d("open","读卡器打开 = "+DeviceModel.getSoport());
//            Toast.makeText(getContext(), "打开成功"+DeviceModel.getSoport(), Toast.LENGTH_SHORT).show();
//            mStartRead = true  ;
//            startRead();
//        }else{
//            Log.d("open","读卡器打开失败 = "+DeviceModel.getSoport());
//            Toast.makeText(getContext(), "打开失败"+DeviceModel.getSoport(), Toast.LENGTH_SHORT).show();
//        }
//
//    }
//
//    private void startRead(){
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while (mStartRead){
//                    //社保卡
//                    byte[] bytes = new byte[256];
//                    long cardBas = SSCardDriver.iReadCardBas(3, bytes);
//                    Log.d(TAG,"11111111111111"+cardBas);
//                    if (cardBas ==0) {
//                        String gbk = null;
//                        try {
//                            gbk = new String(bytes, "gbk");
//                            String strInfo[] = gbk.split("\\|", -1);
//                            Log.d(TAG, "onClick: =="+gbk.toString());
//                            Log.d(TAG,"String"+strInfo.length);
//                            if (strInfo.length == 12) {
//                                infoCard = "\n发卡地区行政区划代码:" + strInfo[0] + "\n社会保障号码:" + strInfo[1] +
//                                        "\n卡号:" + strInfo[2] + "\n卡识别码:" + strInfo[3] + "\n姓名:" + strInfo[4] + "\n卡复位信息:" + strInfo[5] +
//                                        "\n规范版本:" + strInfo[6] + "\n发卡日期:" + strInfo[7] + "\n卡有效期:" + strInfo[8] + "\n终端机编号:" + strInfo[9] + "\n终端设备号:" + strInfo[10];
//                            }
//
//                            //名字
//                            String name=strInfo[4];
//
//                            //社会保证号
//                            String phone=strInfo[1];
//
//                            //社会保障卡号
//                            String birth=strInfo[2];
//
//                            //卡有效期
//                            String valid=strInfo[7];
//
//                            mName=name;
//
//                            mCode=phone;
//
//                            mBonth=birth;
//
//                            mNum=valid;
//
//                            mBundle=new Bundle();
//                            mBundle.putString("name", mName);
//                            mBundle.putString("phone", mCode);
//                            mBundle.putString("birth", mBonth);
//                            mBundle.putString("valid", mNum);
//
//                            mHandler.sendEmptyMessageDelayed(10,0);
//                          /*    getActivity().runOnUiThread(new Runnable() {
//                                  @Override
//                                  public void run() {
//                                     *//* Navigation.findNavController(root).
//                                            navigate(R.id.action_socialFragment_to_showSocialCardsFragment,mBundle);*//*
//
//                                }
//                            });*/
//                            Thread.sleep(1000);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        } catch (UnsupportedEncodingException e) {
//                            e.printStackTrace();
//                        }
//                    }else{
//                        Log.d(TAG, "idCardFragment: 读取失败");
//                        mHandler.sendEmptyMessageDelayed(20,0);
//                    }
//
//                }
//            }
//        }).start();
//    }
//
//
//
//    private void start(View root){
//        Navigation.findNavController(root).navigate(R.id.action_socialFragment_to_showSocialCardsFragment,mBundle);
//        /* mHandler.removeCallbacksAndMessages(null);*/
//        mStartRead = false;
//
//
//    }
//
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        mStartRead = false;
//        //消息清除dc
//        mHandler.removeCallbacksAndMessages(null);
//        /*   mRead = false;*/
//    }
//
//
//
//}
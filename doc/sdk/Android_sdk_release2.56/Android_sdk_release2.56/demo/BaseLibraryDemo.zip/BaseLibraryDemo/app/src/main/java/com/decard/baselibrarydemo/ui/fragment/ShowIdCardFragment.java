package com.decard.baselibrarydemo.ui.fragment;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.decard.baselibrarydemo.R;
import com.decard.baselibrarydemo.model.DeviceModel;

public class ShowIdCardFragment extends Fragment {

    private static final String TAG = "ShowIdCardFragment";

    private TextView mName;

    private TextView mSex;

    private TextView mNation;

    private TextView mBirth;

    private TextView mAddress;

    private TextView mNumber;

    private boolean startRead = false;

    private TextView mSigFor;

    private TextView mValidTime;

    private ImageView mReturn;

    private ImageView mPhone;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View root;
        if (Build.MODEL.equals(DeviceModel.Z90N.deviceName)){
            root = inflater.inflate(R.layout.fragment_id_card_z90n, container, false);
        }else{
            root = inflater.inflate(R.layout.fragment_id_card, container, false);
        }
        LinearLayout naLayout=getActivity().findViewById(R.id.na_layout);
        naLayout.setVisibility(View.GONE);
        initviwe(root);
        return root;
    }

    private void initviwe(View root){
        mReturn=root.findViewById(R.id.btn_return_key_id_card);

        mName=root.findViewById(R.id.idCard_name);

        mSex=root.findViewById(R.id.idCard_sex);

        mNation=root.findViewById(R.id.idCard_nation);

        mBirth=root.findViewById(R.id.idCard_birthday);

        mAddress=root.findViewById(R.id.idCard_address);

        mNumber=root.findViewById(R.id.idCard_num);

        mSigFor=root.findViewById(R.id.idCard_office);

        mValidTime=root.findViewById(R.id.idCard_time);

        mPhone=root.findViewById(R.id.idCard_photo);

        root.setFocusableInTouchMode(true);
        root.requestFocus();
        root.setOnKeyListener((v, keyCode, event) -> {
            if(keyCode == KeyEvent.KEYCODE_BACK){
                NavHostFragment.findNavController(ShowIdCardFragment.this).navigate(R.id.action_showIdCardFragment_to_homeFragment);

                return true;
            }

            return false;
        });

        mReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_showIdCardFragment_to_homeFragment);
            }
        });


        mName.setText(getArguments().getString("name"));
        mSex.setText(getArguments().getString("sex"));
        mNation.setText(getArguments().getString("nation"));
        mBirth.setText(getArguments().getString("birth"));
        mAddress.setText(getArguments().getString("address"));
        mNumber.setText(getArguments().getString("number"));
        mSigFor.setText(getArguments().getString("sigFor"));
        mValidTime.setText(getArguments().getString("validTime"));
        byte[]adb=getArguments().getByteArray("phone");
         Bitmap bitmap = BitmapFactory.decodeByteArray(adb, 0, adb.length);
        mPhone.setImageBitmap(bitmap);
       /* mPhone.setImageBitmap(adb);
        //测试
      /*  mName.setText("小明");
        mSex.setText("男");
        mNation.setText("汉");
        mBirth.setText("2022418");
        mAddress.setText("1111111");
        mNumber.setText("111111111111111111");
        mSigFor.setText("2022418");
        mValidTime.setText("2022418");
        mPhone.setImageResource(R.drawable.m1_img);*/
       /* byte[]adb=getArguments().getByteArray("phone");*/


    }


}
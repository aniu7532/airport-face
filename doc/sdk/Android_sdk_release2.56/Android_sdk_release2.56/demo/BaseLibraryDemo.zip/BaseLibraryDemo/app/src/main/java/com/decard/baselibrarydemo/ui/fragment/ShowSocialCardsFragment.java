//package com.decard.baselibrarydemo.ui.fragment;
//
//import android.os.Build;
//import android.os.Bundle;
//
//import androidx.fragment.app.Fragment;
//import androidx.navigation.fragment.NavHostFragment;
//
//import android.view.KeyEvent;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.decard.baselibrarydemo.R;
//import com.decard.baselibrarydemo.model.DeviceModel;
//
//
//public class ShowSocialCardsFragment extends Fragment {
//
//    private static final String TAG = "@@@@@@@@@@";
//
//    private boolean mStartRead = false;
//
//    private Button mButton;
//
//    private TextView mName;
//
//    private TextView mCode;
//
//    private TextView mSex;
//
//    private TextView mBonth;
//
//    private TextView mNum;
//
//    private   String infoCard;
//
//    private ImageView mReturn;
//
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        if (Build.MODEL.equals(DeviceModel.Z90N.deviceName)){
//            View root= inflater.inflate(R.layout.fragment_social_cards_z90n, container, false);
//            initview(root);
//            return root;
//
//        }else{
//            View root= inflater.inflate(R.layout.fragment_social_cards, container, false);
//            initview(root);
//            return root;
//        }
//
//    }
//    private void initview(View root){
//        mName=root.findViewById(R.id.idCard_name);
//        mCode=root.findViewById(R.id.idCard_sex);
//        mSex=root.findViewById(R.id.idCard_birthday);
//        mBonth=root.findViewById(R.id.id_bnt_so);
//        mNum = root.findViewById(R.id.idCard_num);
//
//        /*mButton=root.findViewById(R.id.btn_rade_card);*/
//
//        mReturn=root.findViewById(R.id.btn_return_key_social);
//
//
//        root.setFocusableInTouchMode(true);
//        root.requestFocus();
//        root.setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//                if(keyCode == KeyEvent.KEYCODE_BACK){
//                    NavHostFragment.findNavController(ShowSocialCardsFragment.this).navigate(R.id.action_showSocialCardsFragment_to_homeFragment);
//
//                    return true;
//                }
//
//                return false;
//            }
//        });
//
//        mReturn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                /*Navigation.findNavController(view).popBackStack();*/
//                NavHostFragment.findNavController(ShowSocialCardsFragment.this).navigate(R.id.action_showSocialCardsFragment_to_homeFragment);
//            }
//        });
//
//
//        mName.setText(getArguments().getString("name"));;
//        mCode.setText(getArguments().getString("phone"));;
//        mBonth.setText(getArguments().getString("birth"));;
//        mNum.setText(getArguments().getString("valid"));;
//
//        //测试
//
//  /*      mName.setText("小明");;
//        mCode.setText("1111111");;
//        mBonth.setText("1111111");;
//        mNum.setText("2022419");;*/
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        mStartRead = false;
//    }
//
//
//
//}
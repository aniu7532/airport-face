package com.decard.baselibrarydemo;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {

     String deviceType;
     String portValue;
     int baudRate;


}
